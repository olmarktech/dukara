@php
    // Pre-render PageBuilder content BEFORE entering sections to avoid section stack corruption
    $pageBuilderContent = '';
    if (isset($page_post) && $page_post->page_builder === 1) {
        $pageBuilderContent = \Plugins\PageBuilder\PageBuilderSetup::render_frontend_pagebuilder_content_for_dynamic_page('dynamic_page', $page_post->id);
        // Sanitize to prevent Blade directive conflicts - remove all problematic Blade directives
        // Handle both Blade syntax and compiled PHP code
        $directives = [
            // Blade syntax patterns
            '/@endsection\s*/i',
            '/@section\s*\([^)]+\)\s*/i',
            '/@endpush\s*/i',
            '/@push\s*\([^)]+\)\s*/i',
            '/@stack\s*\([^)]+\)\s*/i',
            '/@yield\s*\([^)]+\)\s*/i',
            '/@extends\s*\([^)]+\)\s*/i',
            '/@parent\s*/i',
            '/@stop\s*/i',
            '/@append\s*/i',
            '/@overwrite\s*/i',
            '/@endonce\s*/i',
            '/@once\s*/i',
            '/@endcomponent\s*/i',
            '/@component\s*\([^)]+\)\s*/i',
            // Compiled PHP patterns (Blade compiles directives to PHP) - handle various whitespace patterns
            '/<\?php\s*\$__env->stopSection\(\);\s*\?>/is',
            '/<\?php\s*\$__env->startSection\([^)]+\);\s*\?>/is',
            '/<\?php\s*\$__env->stopPush\(\);\s*\?>/is',
            '/<\?php\s*\$__env->startPush\([^)]+\);\s*\?>/is',
            '/<\?php\s*echo\s+\$__env->yieldContent\([^)]+\);\s*\?>/is',
            '/<\?php\s*echo\s+\$__env->yieldPushContent\([^)]+\);\s*\?>/is',
            '/<\?php\s*\$__env->startComponent\([^)]+\);\s*\?>/is',
            '/<\?php\s*\$__env->renderComponent\(\);\s*\?>/is',
        ];
        
        foreach ($directives as $pattern) {
            $pageBuilderContent = preg_replace($pattern, '', $pageBuilderContent);
        }
        
        // Remove any standalone empty PHP tags (multiline)
        $pageBuilderContent = preg_replace('/<\?php\s*\?>\s*/m', '', $pageBuilderContent);
        
        // Remove any remaining section/push related PHP code (more aggressive)
        $pageBuilderContent = preg_replace('/\$__env->(stopSection|startSection|stopPush|startPush|yieldContent|yieldPushContent|startComponent|renderComponent)\([^)]*\);/', '', $pageBuilderContent);
    }
@endphp

@extends('themes.lexend-v4.layouts.app')

@section('page-title', $page_post->title ?? '')

@section('content')
    {{-- Render Page Builder Content --}}
    @if(isset($page_post) && $page_post && $page_post->page_builder === 1)
        @if(isset($page_post->visibility) && $page_post->visibility === 1)
            @if(auth('web')->check())
                {{-- Output pre-rendered page builder content --}}
                {!! $pageBuilderContent !!}
            @else
                <div class="section panel overflow-hidden">
                    <div class="section-outer panel py-6 lg:py-9">
                        <div class="container max-w-xl">
                            <div class="alert alert-warning text-center">
                                <p><a class="uc-link text-primary" href="{{route('landlord.user.login')}}">{{__('Login')}}</a> {{__('to see this page')}} </p>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        @else
            {{-- Output pre-rendered page builder content --}}
            {!! $pageBuilderContent !!}
        @endif
    @elseif(isset($page_post) && $page_post)
        {{-- Regular Page Content --}}
        <div class="section panel overflow-hidden">
            <div class="section-outer panel py-6 lg:py-9">
                <div class="container max-w-xl">
                    <div class="section-inner panel">
                        @if(isset($page_post->visibility) && $page_post->visibility === 1)
                            @if(auth('web')->check())
                                <div class="dynamic-page-content-wrap">
                                    {!! $page_post->page_content ?? '' !!}
                                </div>
                            @else
                                <div class="alert alert-warning text-center">
                                    <p><a class="uc-link text-primary" href="{{route('landlord.user.login')}}">{{__('Login')}}</a> {{__('to see this page')}} </p>
                                </div>
                            @endif
                        @else
                            <div class="dynamic-page-content-wrap">
                                {!! $page_post->page_content ?? '' !!}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endif

    @if(isset($page_post) && Auth::guard('admin')->user())
        @include('tenant.frontend.partials.inpage-edit',['page_post' => $page_post])
    @endif
@endsection

